﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GPSprocessing
{
    public partial class frmGoogleMaps : Form
    {
        public frmGoogleMaps()
        {
            InitializeComponent();
        }

        private void webBrowser1_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {

        }

        private void frmGoogleMaps_Load(object sender, EventArgs e)
        {
            try
            {
                PublicValues pubvars = new PublicValues();
                webBrowser1.Navigate(PublicValues.usethisAddress);
            }
            catch (Exception exxc)
            {
                
                throw;
            }
           
        }
    }
}
