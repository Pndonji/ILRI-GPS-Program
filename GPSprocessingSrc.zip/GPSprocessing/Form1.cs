﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace GPSprocessing
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private string Longitude="";
        private string Latitude="";
        private void translateData()
        {
            if (true)
            {
                //string data = File.ReadAllText(@"C:\Users\Gamer\Desktop\New folder\gpsdata2.txt");
                string data = txtData.Text;
                string[] strArr = data.Split('$');
                for (int i = 0; i < strArr.Length; i++)
                {
                    string strTemp = strArr[i];
                    string[] lineArr = strTemp.Split(',');
                    if (lineArr[0] == "GPGGA")
                    {
                        try
                        {
                            //Latitude
                            Double dLat = Convert.ToDouble(lineArr[2]);
                            int pt = dLat.ToString().IndexOf('.');

                            double degreesLat =
                            Convert.ToDouble(dLat.ToString().Substring(0, pt - 2));

                            double minutesLat =
                    Convert.ToDouble(dLat.ToString().Substring(pt - 2));

                            double DecDegsLat = degreesLat + (minutesLat / 60.0);

                            Latitude = lineArr[3].ToString() + DecDegsLat;

                            //Longitude
                            Double dLon = Convert.ToDouble(lineArr[4]);
                            pt = dLon.ToString().IndexOf('.');

                            double degreesLon =
                    Convert.ToDouble(dLon.ToString().Substring(0, pt - 2));

                            double minutesLon =
                    Convert.ToDouble(dLon.ToString().Substring(pt - 2));

                            double DecDegsLon = degreesLon + (minutesLon / 60.0);

                            Longitude = lineArr[5].ToString() + DecDegsLon;

                            //Display
                            txtLat.Text = Latitude;
                            txtLong.Text = Longitude;

                            //btnMapIt.Enabled = true;
                        }
                        catch(Exception excd)
                        {
                            //Can't Read GPS values
                            //txtLat.Text = "GPS Unavailable";
                            //txtLong.Text = "GPS Unavailable";
                            //btnMapIt.Enabled = false;
                        }
                    }
                }
            }
            else
            {
                //txtLat.Text = "COM Port Closed";
                //txtLong.Text = "COM Port Closed";
                //btnMapIt.Enabled = false;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

            
            translateData();
            PublicValues pubvars = new PublicValues();
            PublicValues.usethisAddress= "https://www.google.com/maps/preview#!q="+txtLat.Text+"%2C"+txtLong.Text;
            txtLink.Text = "https://www.google.com/maps/preview#!q=" + txtLat.Text + "%2C" + txtLong.Text;
            //pubvars.usethisAddress 
            //frmGoogleMaps gotoGmaps = new frmGoogleMaps();
            //gotoGmaps.ShowDialog();
            //this.Close();
            }
            catch (Exception excc)
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtData.Text = "";
            txtLat.Text = "";
            txtLong.Text = "";
            txtLink.Text = "";
        }
    }
}
