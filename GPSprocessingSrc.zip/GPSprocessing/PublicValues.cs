﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GPSprocessing
{
    class PublicValues
    {

        public static string usethisAddress = "";
    }
}
